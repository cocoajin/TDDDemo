<?php
// passthru("/Users/mac/desktop/xcode_build/xx.sh");
passthru("/Users/mac/desktop/xcode_build/build");
?>