//
//  main.m
//  JPEGCompress
//
//  Created by cocoa on 17/4/20.
//  Copyright © 2017年 dev.keke@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        //参数校验
        if (argc!=4) {
            printf("参数错误，请检测！\n");
            printf("本程序主要是对图片进行JPEG压缩\n");
            printf("示例：./JPEGCompress /xxpath/imgfile /xxpath/out.jpeg 0.4 \n");
            printf("参数一：要压缩的图片；参数二：输出路径；参数三：压缩比0.1～1.0之间\n");
            
            return -1000;
        }
    
        NSString *inPath = [NSString stringWithCString:argv[1] encoding:NSUTF8StringEncoding];
        NSString *outPath = [NSString stringWithCString:argv[2] encoding:NSUTF8StringEncoding];
        float compress =  [[NSString stringWithCString:argv[3] encoding:NSUTF8StringEncoding] floatValue];
        
        NSImage *simg = [[NSImage alloc]initWithContentsOfFile:inPath];
        NSData *imgDt = [simg TIFFRepresentation];
        NSBitmapImageRep *imageRep = [NSBitmapImageRep imageRepWithData:imgDt];
        NSDictionary *imageProps = [NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:compress] forKey:NSImageCompressionFactor];
        imgDt = [imageRep representationUsingType:NSJPEGFileType properties:imageProps];
        
        int ret = [imgDt writeToFile:outPath atomically:YES];
        if (ret>0) {
            printf("in: %s\nout: %s\ncompress: %s\nSUCCESS\n",argv[1],argv[2],argv[3]);
        }else
        {
            printf("FAILURE!\n");
        }
        return ret;
        
        
        
    
    }
    return 0;
}
