//
//  ViewController.h
//  JPEGCom
//
//  Created by cocoa on 17/4/20.
//  Copyright © 2017年 dev.keke@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

