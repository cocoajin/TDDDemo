//
//  ViewController.m
//  JPEGCom
//
//  Created by cocoa on 17/4/20.
//  Copyright © 2017年 dev.keke@gmail.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImage *timg = [UIImage imageWithContentsOfFile:@"/Users/cocoajin/Desktop/testiOS/IMG_0420.PNG"];
    for (int i = 0; i <10; i++) {
        NSData *cd = UIImageJPEGRepresentation(timg, (i+1)/10.0f);
        [cd writeToFile:[NSString stringWithFormat:@"/Users/cocoajin/Desktop/testiOS/com%.1f.jpeg",(i+1)/10.0f] atomically:YES];
    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
