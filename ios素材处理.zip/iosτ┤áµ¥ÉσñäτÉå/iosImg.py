#coding=utf-8
#自动生成iOS上1x，2x,3x图
#dev.keke@gmail.com
#17-04-19




from sys import argv
import os.path,Image

#verify input
if  len(argv)!=5 or argv[1]=='-h':
	print "调用错误，请参考如下说明"
	print "使用该脚本自生成ios上 1x,2x,3x图片"
	print "使用示例，生成loginBtn.png(100,100),loginBtn@2x.png(200,200),loginBtn@3x.png(300,300)"
	print "python xxx.py ~/path/test.png loginBtn 100 100"
	print ""
	exit()


#in
infile = argv[1]
inName = argv[2]
inWidth = int(argv[3])
inHeight = int(argv[4])
fpath,fname = os.path.split(infile)
img = Image.open(infile)
img = img.convert("RGBA")
x,y = img.size
print "infile: " + infile
print "inSize: (" + str(x) + "," + str(y) +")"


#out
out1x = fpath + "/" + inName + ".png"
out2x = fpath + "/" + inName + "@2x.png"
out3x = fpath + "/" + inName + "@3x.png"
save1x = img.resize((inWidth*1,inHeight*1))
save1x.save(out1x)
save2x = img.resize((inWidth*2,inHeight*2))
save2x.save(out2x)
save3x = img.resize((inWidth*3,inHeight*3))
save3x.save(out3x)
print "out:"
print out1x + "  size: (" + str(inWidth*1) +","+ str(inHeight*1) +")"
print out2x + "  size: (" + str(inWidth*2) +","+ str(inHeight*2) +")"
print out3x + "  size: (" + str(inWidth*3) +","+ str(inHeight*3) +")"

print "SUCCESS"


